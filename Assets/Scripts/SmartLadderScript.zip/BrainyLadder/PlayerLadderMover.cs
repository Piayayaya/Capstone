﻿using UnityEngine;

public class PlayerLadderMover : MonoBehaviour
{
    [Header("Player Settings")]
    public RectTransform playerIcon;       // Your player UI object inside ScrollView Content
    public RectTransform[] levelPositions; // All the ladder levels (set in Inspector)

    private int currentLevel = 0;

    /// <summary>
    /// Move the player to the next ladder level.
    /// </summary>
    public void MoveToNextLevel()
    {
        if (currentLevel < levelPositions.Length - 1)
        {
            currentLevel++;
            MoveToLevel(currentLevel);
        }
        else
        {
            Debug.Log("🏆 Player reached the last level!");
        }
    }

    /// <summary>
    /// Instantly move to a given level index.
    /// </summary>
    public void MoveToLevel(int levelIndex)
    {
        if (levelIndex >= 0 && levelIndex < levelPositions.Length)
        {
            playerIcon.anchoredPosition = levelPositions[levelIndex].anchoredPosition;
        }
    }

    /// <summary>
    /// Reset player back to the start (Level 0).
    /// </summary>
    public void ResetPlayer()
    {
        currentLevel = 0;
        MoveToLevel(currentLevel);
    }
}

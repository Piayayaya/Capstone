using UnityEngine;
using TMPro;

public class SmartLadderGenerator : MonoBehaviour
{
    [Header("Prefabs")]
    public GameObject oddPrefab;   // prefab for odd levels (ladder facing right)
    public GameObject evenPrefab;  // prefab for even levels (ladder facing left)
    public GameObject chestPrefab;

    [Header("Parent")]
    public Transform parent;       // parent container (e.g., ScrollView Content)

    [Header("Settings")]
    public int totalLevels = 10;   // how many levels to generate
    public float ySpacing = 485f;  // vertical distance between levels
    public float yOffset = 550f;    // starting offset for Y (extra space at bottom)
    public float oddX = -195f;     // x position for odd numbers
    public float evenX = 491.5f;   // x position for even numbers
    public float chestX = 0;
    public float chestY = 0;


    void Start()
    {
        GenerateLadder();
    }

    void GenerateLadder()
    {
        for (int i = 1; i <= totalLevels; i++)
        {
            // Pick prefab based on odd/even
            GameObject prefabToUse = (i % 2 == 1) ? oddPrefab : evenPrefab;

            // Calculate position
            float xPos = (i % 2 == 1) ? oddX : evenX;
            float yPos = yOffset + (i - 1) * ySpacing;

            // Spawn
            GameObject levelObj = Instantiate(prefabToUse, parent);
            levelObj.transform.localPosition = new Vector3(xPos, yPos, 0);

            // Set TMP number
            TMP_Text numberText = levelObj.GetComponentInChildren<TMP_Text>();
            if (numberText != null)
            {
                numberText.text = i.ToString();
            }
        }
        GameObject chest = Instantiate(chestPrefab, parent);
        chest.transform.localPosition = new Vector3(chestX, chestY, 0);
    }
}

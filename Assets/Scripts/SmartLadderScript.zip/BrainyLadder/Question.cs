[System.Serializable]
public class Question
{
    public int Id;                // useful later for database
    public string Difficulty;     // "Easy", "Medium", "Advanced"
    public string QuestionText;
    public string[] Choices;      // always 3 choices
    public int CorrectAnswerIndex; // 0,1,2
    public string Explanation;
}

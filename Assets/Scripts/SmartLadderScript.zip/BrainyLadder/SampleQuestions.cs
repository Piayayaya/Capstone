﻿using System.Collections.Generic;

public class SampleQuestions : IQuestionProvider
{
    private List<Question> allQuestions = new List<Question>()
    {
        new Question {
            Id = 1,
            Difficulty = "Easy",
            QuestionText = "What is the capital of the Philippines?",
            Choices = new string[] {"Manila", "Cebu", "Davao"},
            CorrectAnswerIndex = 0,
            Explanation = "Manila is the capital city of the Philippines."
        },
        new Question {
            Id = 2,
            Difficulty = "Easy",
            QuestionText = "2 + 2 = ?",
            Choices = new string[] {"3", "4", "5"},
            CorrectAnswerIndex = 1,
            Explanation = "2 plus 2 equals 4."
        },

        // Add more... total 20 questions for Easy/Medium/Advanced
    };

    public List<Question> GetQuestionsByDifficulty(string difficulty)
    {
        return allQuestions.FindAll(q => q.Difficulty == difficulty);
    }
}

using System.Collections.Generic;

public interface IQuestionProvider
{
    List<Question> GetQuestionsByDifficulty(string difficulty);
}

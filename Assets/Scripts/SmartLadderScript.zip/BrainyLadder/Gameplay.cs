﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class GameManager : MonoBehaviour
{
    [Header("UI References")]
    public Text questionText;
    public Button[] choiceButtons; // 3 buttons
    public Text explanationText;
    public GameObject explanationPanel;

    private IQuestionProvider questionProvider;
    private List<Question> currentQuestions;
    private int currentQuestionIndex = 0;
    private int coins = 0;

    void Start()
    {
        // For now, use sample provider
        questionProvider = new SampleQuestions();
    }

    public void StartGame(string difficulty)
    {
        currentQuestions = questionProvider.GetQuestionsByDifficulty(difficulty);
        currentQuestionIndex = 0;
        ShowQuestion();
    }

    void ShowQuestion()
    {
        if (currentQuestionIndex >= currentQuestions.Count)
        {
            Debug.Log("Game Over! Total Coins: " + coins);
            return;
        }

        Question q = currentQuestions[currentQuestionIndex];
        questionText.text = q.QuestionText;

        for (int i = 0; i < choiceButtons.Length; i++)
        {
            int choiceIndex = i;
            choiceButtons[i].GetComponentInChildren<Text>().text = q.Choices[i];
            choiceButtons[i].onClick.RemoveAllListeners();
            choiceButtons[i].onClick.AddListener(() => OnChoiceSelected(choiceIndex));
        }

        explanationPanel.SetActive(false);
    }

    void OnChoiceSelected(int choiceIndex)
    {
        Question q = currentQuestions[currentQuestionIndex];
        bool isCorrect = choiceIndex == q.CorrectAnswerIndex;

        if (isCorrect)
        {
            coins += 10; // reward system
            explanationText.text = "Correct! " + q.Explanation;
        }
        else
        {
            explanationText.text = "Wrong! " + q.Explanation;
        }

        explanationPanel.SetActive(true);
        currentQuestionIndex++;
    }

    public void NextQuestion()
    {
        ShowQuestion();
    }
}
